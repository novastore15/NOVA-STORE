// Clave publishable: está diseñada para usarse en el navegador. Nunca pongas aquí service_role.

(() => {
    const SUPABASE_URL = 'https://jfmeosfqmeevultkuzaw.supabase.co';
    const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_1xh9-wapU_XlS_HRRw09Dw_AJXOJi0Y';

    window.supabaseClient = window.supabase.createClient(
        SUPABASE_URL,
        SUPABASE_PUBLISHABLE_KEY,
        {
            auth: {
                persistSession: true,
                autoRefreshToken: true,
                detectSessionInUrl: true
            }
        }
    );
})();