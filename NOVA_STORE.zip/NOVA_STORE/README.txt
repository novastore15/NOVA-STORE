NOVA STORE - INTRANET, EXTRANET Y SUPABASE

ARCHIVOS
- index.html: página pública de NOVA STORE. En la sección Accesos solo muestra los enlaces Intranet y Extranet.
- intranet.html: inicio de sesión privado para empleados/administradores.
- extranet.html: inicio de sesión privado para proveedores/administradores.
- portal.css: diseño común verde oscuro y azul oscuro.
- supabase-config.js: URL y clave publishable del proyecto.
- database.sql: tablas, funciones, permisos y políticas RLS para este paquete.

CONFIGURACIÓN
1. Abre el proyecto Supabase novastore.
2. En SQL Editor, ejecuta database.sql completo.
3. En Authentication > Providers, habilita Email. Decide si exigir confirmación de correo.
4. Crea usuarios empleados, proveedores y administrador desde Authentication > Users (no publiques un formulario para crear esos roles).
5. Después de crear cada cuenta, asigna su rol desde SQL Editor con una de estas sentencias, reemplazando el correo:
   update auth.users set raw_app_meta_data = coalesce(raw_app_meta_data,'{}'::jsonb) || '{"role":"empleado"}'::jsonb where email='empleado@tuempresa.com';
   update auth.users set raw_app_meta_data = coalesce(raw_app_meta_data,'{}'::jsonb) || '{"role":"proveedor"}'::jsonb where email='proveedor@empresa.com';
   update auth.users set raw_app_meta_data = coalesce(raw_app_meta_data,'{}'::jsonb) || '{"role":"admin"}'::jsonb where email='admin@tuempresa.com';
6. Cierra sesión y vuelve a iniciar sesión en la web para renovar el JWT con el rol actualizado.
7. Publica todos los archivos en la misma carpeta/hosting para que los enlaces relativos funcionen.

SEGURIDAD
- La clave incluida es publishable (antes anon), apta para el navegador. Nunca incluyas service_role ni secret keys en archivos públicos.
- La autorización no depende de un valor enviado por el formulario: se verifica app_metadata.role y la base de datos aplica RLS.
- Los registros públicos creados desde la tienda reciben rol cliente. Solo administración asigna empleado/proveedor/admin.
- Los pedidos requieren que el cliente inicie sesión. El formulario de contacto permite enviar mensajes, pero no leerlos.
- Los pagos no se procesan en línea; el método elegido se guarda como dato del pedido.

NOTA
Este paquete crea tablas nuevas con prefijo nova_ para no alterar tablas anteriores del proyecto. Los paneles empiezan vacíos hasta que administración cargue comunicados, tareas y órdenes de proveedores.
